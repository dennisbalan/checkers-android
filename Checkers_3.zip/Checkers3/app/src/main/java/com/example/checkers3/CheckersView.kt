package com.example.checkers3

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.util.AttributeSet
import android.util.Log
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.View
import androidx.core.view.GestureDetectorCompat

class CheckersView (context: Context, attrs: AttributeSet?) : View(context,attrs), GestureDetector.OnGestureListener {
    private var mDetector = GestureDetectorCompat(this.context, this)
    private var squareColor = Color.GREEN
    private var height = 0.0f
    private var width = 0.0f
    private var tenWidth = 0.0f
    private var tenHeight = 0.0f
    private var ten = 0.0f
    private var smallest = 0.0f
    private var array = arrayOf<Array<Int>>()
    private var current = 2
    private var waiting = 3
    private var GameOver = 0
    private var win1 = 0
    private var win2 = 0
    private var red_x = 15
    private var red_y = 15
    private var blue_x = 15
    private var blue_y = 15
    private var capture = 0
    private var captured = 0
    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        height = h.toFloat()
        width = w.toFloat()
        if (height > width) {
            smallest = width
            ten = width / 8
        }
        if (width > height) {
            smallest = height
            ten = height / 8
        }
        for (i in 0..9) {
            var temp = arrayOf<Int>()
            for (j in 0..9) {
                temp += 0
            }
            array += temp
        }
        for (i in 0..8) {
            for (j in 0..8) {
                if ((j % 2 == 0) && (i % 2 != 0) || ((j % 2 != 0) && (i % 2 == 0))) {
                    array[j][i] = 1
                }
            }
            for (k in 0..8) {
                if (k % 2 == 0) {
                    array[7][k] = 3
                    array[1][k] = 2
                    array[5][k] = 3

                }
                if(k%2 != 0){
                    array[0][k] = 2
                    array[6][k] = 3
                    array[2][k] = 2
                }
            }

        }
    }
    override fun onTouchEvent(event: MotionEvent?): Boolean {
        if (mDetector.onTouchEvent(event)) {
            return true
        }
        return super.onTouchEvent(event)
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val paint = Paint()
        paint.color = Color.BLACK
        for (i in 0..8) {
            canvas.drawLine(0.0f, i * ten, smallest, i * ten, paint)
            canvas.drawLine(i * ten, smallest, i * ten, 0.0f, paint)
        }
        for (i in 0..7) {
            for (j in 0..7) {
                if (array[j][i] == 1) {
                    paint.color = Color.BLACK
                    paint.textSize = 100f
                    paint.textAlign = Paint.Align.CENTER
                    canvas.drawRect(i *ten,j * ten,i *ten + ten, j * ten + ten,paint)
                    paint.color = Color.BLUE
                    //canvas.drawCircle((i * ten) + ten/2, (ten*j)  + ten/2,ten/2,paint)
                }
                if (array[j][i] == 2) {
                    paint.color = Color.BLACK
                    paint.textSize = 100f
                    paint.textAlign = Paint.Align.CENTER
                    canvas.drawRect(i *ten,j * ten,i *ten + ten, j * ten + ten,paint)
                    paint.color = Color.RED
                    canvas.drawCircle((i * ten) + ten/2, (ten*j)  + ten/2,ten/2,paint)
                }
                if (array[j][i] == 3) {
                    paint.color = Color.BLACK
                    paint.textSize = 100f
                    paint.textAlign = Paint.Align.CENTER
                    canvas.drawRect(i *ten,j * ten,i *ten + ten, j * ten + ten,paint)
                    paint.color = Color.BLUE
                    canvas.drawCircle((i * ten) + ten/2, (ten*j)  + ten/2,ten/2,paint)
                    Log.d("Stuff",array[j][i].toString())
                }
                if (array[j][i] == 4) {
                    paint.color = Color.GREEN
                    paint.textSize = 100f
                    paint.textAlign = Paint.Align.CENTER
                    canvas.drawRect(i *ten,j * ten,i *ten + ten, j * ten + ten,paint)
                    Log.d("Stuff",array[j][i].toString())
                }
                if (array[j][i] == 5) {
                    paint.color = Color.BLACK
                    paint.textSize = 100f
                    paint.textAlign = Paint.Align.CENTER
                    canvas.drawRect(i *ten,j * ten,i *ten + ten, j * ten + ten,paint)
                    paint.color = Color.GREEN
                    canvas.drawCircle((i * ten) + ten/2, (ten*j)  + ten/2,ten/2,paint)
                    Log.d("Stuff",array[j][i].toString())
                }
                if (array[j][i] == 6) {
                    paint.color = Color.BLACK
                    paint.textSize = 100f
                    paint.textAlign = Paint.Align.CENTER
                    canvas.drawRect(i *ten,j * ten,i *ten + ten, j * ten + ten,paint)
                    paint.color = Color.YELLOW
                    canvas.drawCircle((i * ten) + ten/2, (ten*j)  + ten/2,ten/2,paint)
                    Log.d("Stuff",array[j][i].toString())
                }

            }
        }
        if(width < height) {
            paint.color = Color.RED
            paint.textSize = 50f
            paint.textAlign = Paint.Align.CENTER
            canvas.drawText("Player", (1 * ten), (10 * ten), paint)
            paint.textSize = 100f
            if(current == 2){
                canvas.drawText("Red", (1 * ten), (11 * ten), paint)
                if(Score(waiting) == 0){
                    paint.textSize = 75f
                    canvas.drawText("Red win", (1 * ten), (11 * ten), paint)
                }
            }
            else{
                canvas.drawText("Blue", (1 * ten), (11 * ten), paint)
                if(Score(waiting) == 0){
                    paint.textSize = 75f
                    canvas.drawText("Blue win", (1 * ten), (11 * ten), paint)
                }
            }
            paint.textSize = 50f
            canvas.drawText("Red Score", (3 * ten), (10 * ten), paint)
            paint.textSize = 100f
            canvas.drawText((Score(2)-1).toString(), (3 * ten), (11 * ten), paint)
            paint.textSize = 50f
            canvas.drawText("Blue Score", (5 * ten), (10 * ten), paint)
            paint.textSize = 100f
            canvas.drawText((Score(3)-2).toString(), (5 * ten), (11 * ten), paint)
            paint.textSize = 75f
            canvas.drawText("Reset", 7 * ten, 11 * ten, paint)
            paint.textSize = 50f
            canvas.drawText("Blue Queen ", 2 * ten, 12 * ten, paint)
            canvas.drawText("Red Queen ", 6 * ten, 12 * ten, paint)
            canvas.drawText("Green", 2 * ten, 13 * ten, paint)
            canvas.drawText("Yellow", 6 * ten, 13 * ten, paint)

        }
        if(height < width){
            paint.color = Color.RED
            paint.textSize = 50f
            paint.textAlign = Paint.Align.CENTER
            canvas.drawText("Player", (11 * ten), (1 * ten), paint)
            paint.textSize = 100f
            canvas.drawText(current.toString(), (12 * ten), (1 * ten), paint)
            paint.textSize = 50f
            canvas.drawText("Score 1", (11 * ten), (3 * ten), paint)
            paint.textSize = 100f
            canvas.drawText(Score(2).toString(), (12 * ten), (3 * ten), paint)
            paint.textSize = 50f
            canvas.drawText("Score 2", (11 * ten), (5 * ten), paint)
            paint.textSize = 100f
            canvas.drawText(Score(3).toString(), (12 * ten), (5 * ten), paint)
            canvas.drawText("Reset", 12 * ten, 7 * ten, paint)
        }
    }

    override fun onDown(p0: MotionEvent?): Boolean {
        return true
    }

    override fun onShowPress(p0: MotionEvent?) {
    }

    override fun onSingleTapUp(p0: MotionEvent?): Boolean {
        var x_value = 0
        var y_value = 0
        if (p0 != null) {
            if(p0.y > (11*ten) && p0.x < (12 *ten)){
                if(p0.y > (6*ten) && p0.x < (7 *ten)){
                    for (i in 0..9) {
                        var temp = arrayOf<Int>()
                        for (j in 0..9) {
                            temp += 0
                        }
                        array += temp
                    }
                    for (i in 0..8) {
                        for (j in 0..8) {
                            if ((j % 2 == 0) && (i % 2 != 0) || ((j % 2 != 0) && (i % 2 == 0))) {
                                array[j][i] = 1
                            }
                        }
                        for (k in 0..8) {
                            if (k % 2 == 0) {
                                array[7][k] = 3
                                array[1][k] = 2
                                array[5][k] = 3

                            }
                            if(k%2 != 0){
                                array[0][k] = 2
                                array[6][k] = 3
                                array[2][k] = 2
                            }
                        }

                    }
                }
            }
            for (i in 0..8) {
                if ((p0.x >= (i * ten)) && (p0.x <= ((i + 1) * ten))) {
                    x_value = i
                }
                if (p0.y >= (i * ten) && p0.y <= ((i + 1)) * ten) {
                    y_value = i
                }
            }


        }
        Log.d("X-Value - 1",x_value.toString())
        Log.d("X,Y",x_value.toString() + " " + y_value.toString())
        testCells(x_value, y_value,1)
        invalidate()
        return true
    }

    override fun onLongPress(p0: MotionEvent?) {
    }

    override fun onScroll(p0: MotionEvent?, p1: MotionEvent?, p2: Float, p3: Float): Boolean {
        return false
    }

    override fun onFling(p0: MotionEvent?, p1: MotionEvent?, p2: Float, p3: Float): Boolean{
        return false
    }

    private fun testCells(x_value: Int, y_value: Int,replace:Int) {
        Log.d("Sequence Initiaited","In TestCells")
        Log.d("Sequence Working",array[x_value][y_value].toString())
        Log.d("X,Y in TestCells",x_value.toString() + " " + y_value.toString())
        if(array[y_value][x_value] == 2 && current == 2){
            captured = 0
            Log.d("Checkers Red",jump_test().toString())
            for(i in 0..8){
                for(j in 0..8){
                    if(array[j][i] == 4){
                        array[j][i] = 1
                    }
                }
            }
            capture = 0
            if(x_value == 0) {
                if (array[y_value + 1][x_value + 1] == 1 && jump_test() == 0) {
                    array[y_value + 1][x_value + 1] = 4
                }
                if ((array[y_value + 1][x_value + 1] == 3 || array[y_value + 1][x_value + 1] == 5) && array[y_value + 2][x_value + 2] == 1) {
                    array[y_value + 2][x_value + 2] = 4
                    blue_x = x_value + 1
                    blue_y = y_value + 1
                    capture = 1
                }
                red_x = x_value
                red_y = y_value
                invalidate()
            }
            else if(x_value == 1){
                if(array[y_value+1][x_value+1] == 1 && jump_test() == 0){
                    array[y_value+1][x_value+1] = 4
                }
                if (array[y_value + 1][x_value - 1] == 1 &&  jump_test() == 0) {
                    array[y_value + 1][x_value - 1] = 4
                }
                if((array[y_value+1][x_value+1] == 3|| array[y_value + 1][x_value + 1] == 5) && array[y_value+2][x_value+2] == 1){
                    array[y_value+2][x_value+2] = 4
                    blue_x = x_value+1
                    blue_y = y_value+1
                    capture = 1

                }
                red_x = x_value
                red_y = y_value
            }
            else if (y_value == 6){
                if(array[y_value+1][x_value+1] == 1 && jump_test() == 0){
                    array[y_value+1][x_value+1] = 4
                }
                if (array[y_value + 1][x_value - 1] == 1 &&  jump_test() == 0) {
                    array[y_value + 1][x_value - 1] = 4
                }
                red_x = x_value
                red_y = y_value
            }
            else {
                if (array[y_value + 1][x_value + 1] == 1 && array[y_value + 1][x_value - 1] == 1 && jump_test() == 0) {
                    array[y_value + 1][x_value + 1] = 4
                    array[y_value + 1][x_value - 1] = 4
                } else if (array[y_value + 1][x_value + 1] == 1 && jump_test() == 0) {
                    array[y_value + 1][x_value + 1] = 4
                } else if (array[y_value + 1][x_value - 1] == 1 && jump_test() == 0) {
                    array[y_value + 1][x_value - 1] = 4
                }
                if ((array[y_value + 1][x_value - 1] == 3 || array[y_value + 1][x_value - 1] == 5)&& array[y_value + 2][x_value - 2] == 1) {
                    array[y_value + 2][x_value - 2] = 4
                    blue_x = x_value - 1
                    blue_y = y_value + 1
                    capture = 1
                }
                if ((array[y_value + 1][x_value + 1] == 3 || array[y_value + 1][x_value + 1] == 5) && array[y_value + 2][x_value + 2] == 1) {
                    array[y_value + 2][x_value + 2] = 4
                    blue_x = x_value + 1
                    blue_y = y_value + 1
                    capture = 1
                }
                red_x = x_value
                red_y = y_value
                invalidate()
            }
        }
        if(array[y_value][x_value] == 4 && current == 2){
            if(capture == 1 && ((y_value-2 == red_y && x_value-2 == red_x ) || ((y_value -2 == red_y) && (x_value+2 == red_x)))){
                //array[blue_y][blue_x] = 1
                    if(y_value-2 == red_y && x_value-2 == red_x){
                        array[y_value-1][x_value-1] = 1
                    }
                    else if(y_value-2 == red_y && x_value+2 == red_x){
                        array[y_value-1][x_value+1] = 1
                    }
                    captured = 1
                capture = 0
            }
            else if(capture == 1 && ((y_value+2 == red_y && x_value+2 == red_x ) || ((y_value  +2 == red_y) && (x_value-2 == red_x)))){
                //array[blue_y][blue_x] = 1
                if(y_value+2 == red_y && x_value-2 == red_x){
                    array[y_value+1][x_value-1] = 1
                }
                else if(y_value+2 == red_y && x_value+2 == red_x){
                    array[y_value+1][x_value+1] = 1
                }
                captured = 1
                capture = 0
            }
            capture = 0
            if(array[red_y][red_x] == 6){
                array[y_value][x_value] = 6
            }else{
                array[y_value][x_value] = 2
            }

            array[red_y][red_x] = 1
            for(i in 0..8){
                for(j in 0..8){
                    if(array[j][i] == 4){
                        array[j][i] = 1
                    }
                }
            }
            if(y_value == 7){
                array[y_value][x_value] = 6
                array[red_y][red_x] = 1
            }
            red_y = y_value
            red_x = x_value
            if(jump_test() == 0 || jump_test() == 1 || captured != 1) {
                var temp = current
                current = waiting
                waiting = temp
            }

        }
        if(array[y_value][x_value] == 3 && current == 3) {
            for (i in 0..8) {
                for (j in 0..8) {
                    if (array[j][i] == 4) {
                        array[j][i] = 1
                    }
                }
            }
            captured = 0
            capture = 0
            if(x_value == 0) {
                if (array[y_value - 1][x_value + 1] == 1 && jump_test() == 0) {
                    array[y_value - 1][x_value + 1] = 4
                }
                if ((array[y_value - 1][x_value + 1] == 2 || array[y_value - 1][x_value + 1] ==  6) && array[y_value - 2][x_value + 2] == 1) {
                    array[y_value - 2][x_value + 2] = 4
                    red_x = x_value + 1
                    red_y = y_value - 1
                    capture = 1
                }
                blue_x = x_value
                blue_y = y_value
                invalidate()
            } else if (x_value == 1){
                if (array[y_value - 1][x_value + 1] == 1 && jump_test() == 0) {
                    array[y_value - 1][x_value + 1] = 4
                }
                if (array[y_value - 1][x_value - 1] == 1 && jump_test() == 0) {
                    array[y_value - 1][x_value - 1] = 4
                }
                if ((array[y_value - 1][x_value + 1] == 2 || array[y_value - 1][x_value + 1] == 6)&& array[y_value - 2][x_value + 2] == 1) {
                    array[y_value - 2][x_value + 2] = 4
                    red_x = x_value + 1
                    red_y = y_value - 1
                    capture = 1
                }
                blue_x = x_value
                blue_y = y_value
            }else if(y_value == 1){
                if (array[y_value - 1][x_value + 1] == 1 && array[y_value - 1][x_value - 1] == 1 && jump_test() == 0) {
                    array[y_value - 1][x_value + 1] = 4
                    array[y_value - 1][x_value - 1] = 4
                }
                else if (array[y_value - 1][x_value + 1] == 1 && jump_test() == 0 ){
                    array[y_value - 1][x_value + 1] = 4
                }
                else if (array[y_value - 1][x_value - 1] == 1 && jump_test() == 0){
                    array[y_value-1][x_value-1] == 4
                }
                if ((array[y_value - 1][x_value + 1] == 2 || array[y_value - 1][x_value + 1] == 6) && array[y_value - 2][x_value + 2] == 1) {
                        array[y_value - 2][x_value + 2] = 4
                        red_x = x_value + 1
                        red_y = y_value - 1
                        capture = 1
                }
                blue_x = x_value
                blue_y = y_value
            }
            else {
                if (array[y_value - 1][x_value + 1] == 1 && array[y_value - 1][x_value - 1] == 1 && jump_test() == 0) {
                    array[y_value - 1][x_value + 1] = 4
                    array[y_value - 1][x_value - 1] = 4
                }
                if (array[y_value - 1][x_value + 1] == 1 && jump_test() == 0) {
                    array[y_value - 1][x_value + 1] = 4
                }
                if (array[y_value - 1][x_value - 1] == 1 && jump_test() == 0) {
                    array[y_value - 1][x_value - 1] = 4
                }
                if ((array[y_value - 1][x_value - 1] == 2 || array[y_value - 1][x_value - 1] == 6) && array[y_value - 2][x_value - 2] == 1) {
                    array[y_value - 2][x_value - 2] = 4
                    red_x = x_value - 1
                    red_y = y_value - 1
                    capture = 1
                }
                if ((array[y_value - 1][x_value + 1] == 2 || array[y_value - 1][x_value + 1] == 6) && array[y_value - 2][x_value + 2] == 1) {
                    array[y_value - 2][x_value + 2] = 4
                    red_x = x_value + 1
                    red_y = y_value - 1
                    capture = 1
                }
                blue_x = x_value
                blue_y = y_value
            }

        }
        if (array[y_value][x_value] == 4 && current == 3) {

                if (capture == 1 && ((y_value + 2 == blue_y && x_value - 2 == blue_x) || ((y_value + 2 == blue_y) && (x_value + 2 == blue_x)))) {
                    array[red_y][red_x] = 1
                    captured = 1
                }
                if(capture == 1 && ((y_value - 2 == blue_y && x_value - 2 == blue_x) || (y_value - 2 == blue_y && x_value  + 2 == blue_x))){
                    array[red_y][red_x] = 1
                    captured = 1
                }
                capture = 0
                if(array[blue_y][blue_x] == 5){
                    array[y_value][x_value] = 5
                }else {
                    array[y_value][x_value] = 3
                }
                array[blue_y][blue_x] = 1
                for (i in 0..8) {
                    for (j in 0..8) {
                        if (array[j][i] == 4) {
                            array[j][i] = 1
                        }
                    }
                }
                if(y_value == 0){
                    array[y_value][x_value] = 5
                    array[blue_y][blue_x] = 1
                }
            blue_y = y_value
            blue_x = x_value
            if(jump_test() == 0 || jump_test() == 1 || captured != 1) {
                var temp = current
                current = waiting
                waiting = temp
            }
            }
        if(array[y_value][x_value] == 6 && current == 2){
            captured = 0
            Log.d("Checkers Red","Initiated")
            for(i in 0..8){
                for(j in 0..8){
                    if(array[j][i] == 4){
                        array[j][i] = 1
                    }
                }
            }
            capture = 0
            if(x_value == 0) {
                if (array[y_value + 1][x_value + 1] == 1 && jump_test() == 0) {
                    array[y_value + 1][x_value + 1] = 4
                }
                if (array[y_value - 1][x_value + 1] == 1 && jump_test() == 0) {
                    array[y_value - 1][x_value + 1] = 4
                }
                if ((array[y_value + 1][x_value + 1] == 3 || array[y_value + 1][x_value + 1] == 5) && array[y_value + 2][x_value + 2] == 1) {
                    array[y_value + 2][x_value + 2] = 4
                    blue_x = x_value + 1
                    blue_y = y_value + 1
                    capture = 1
                }
                if ((array[y_value - 1][x_value + 1] == 3 || array[y_value - 1][x_value + 1] == 5) && array[y_value - 2][x_value + 2] == 1) {
                    array[y_value - 2][x_value + 2] = 4
                    blue_x = x_value + 1
                    blue_y = y_value - 1
                    capture = 1
                }
                red_x = x_value
                red_y = y_value
                invalidate()
            }
            else if(x_value == 1) {
                if (array[y_value + 1][x_value + 1] == 1 && jump_test() == 0) {
                    array[y_value + 1][x_value + 1] = 4
                }
                if (array[y_value - 1][x_value + 1] == 1 && jump_test() == 0) {
                    array[y_value - 1][x_value + 1] = 4
                }
                if (array[y_value + 1][x_value - 1] == 1 && jump_test() == 0) {
                    array[y_value + 1][x_value - 1] = 4
                }
                if (array[y_value - 1][x_value - 1] == 1 && jump_test() == 0) {
                    array[y_value - 1][x_value - 1] = 4
                }
                if ((array[y_value + 1][x_value + 1] == 3 || array[y_value + 1][x_value + 1] == 5) && array[y_value + 2][x_value + 2] == 1) {
                    array[y_value + 2][x_value + 2] = 4
                    blue_x = x_value + 1
                    blue_y = y_value + 1
                    capture = 1
                }
                if ((array[y_value - 1][x_value + 1] == 3 || array[y_value - 1][x_value + 1] == 5) && array[y_value - 2][x_value + 2] == 1) {
                    array[y_value - 2][x_value + 2] = 4
                    blue_x = x_value + 1
                    blue_y = y_value - 1
                    capture = 1
                }
                red_x = x_value
                red_y = y_value
                invalidate()
            }
            else if(y_value == 7){
                if (array[y_value - 1][x_value + 1] == 1 && array[y_value - 1][x_value - 1] == 1 && jump_test() == 0) {
                    array[y_value - 1][x_value + 1] = 4
                    array[y_value - 1][x_value - 1] = 4
                } else if (array[y_value - 1][x_value + 1] == 1 && jump_test() == 0) {
                    array[y_value - 1][x_value + 1] = 4
                } else if (array[y_value - 1][x_value - 1] == 1 && jump_test() == 0) {
                    array[y_value + 1][x_value - 1] = 4
                }
                if ((array[y_value - 1][x_value - 1] == 3 || array[y_value - 1][x_value - 1] == 5) && array[y_value - 2][x_value - 2] == 1) {
                    array[y_value - 2][x_value - 2] = 4
                    blue_x = x_value - 1
                    blue_y = y_value - 1
                    capture = 1
                }
                if ((array[y_value - 1][x_value + 1] == 3 || array[y_value - 1][x_value + 1] == 5) && array[y_value - 2][x_value + 2] == 1) {
                    array[y_value - 2][x_value + 2] = 4
                    blue_x = x_value + 1
                    blue_y = y_value + 1
                    capture = 1
                }
                red_x = x_value
                red_y = y_value
            }
            else if(y_value == 6){
                if(array[y_value+1][x_value+1] == 1 && jump_test() == 0){
                    array[y_value+1][x_value+1] = 4
                }
                if (array[y_value + 1][x_value - 1] == 1 &&  jump_test() == 0) {
                    array[y_value + 1][x_value - 1] = 4
                }
                if (array[y_value - 1][x_value + 1] == 1 && array[y_value - 1][x_value - 1] == 1 && jump_test() == 0) {
                    array[y_value - 1][x_value + 1] = 4
                    array[y_value - 1][x_value - 1] = 4
                } else if (array[y_value - 1][x_value + 1] == 1 && jump_test() == 0) {
                    array[y_value - 1][x_value + 1] = 4
                } else if (array[y_value - 1][x_value - 1] == 1 && jump_test() == 0) {
                    array[y_value + 1][x_value - 1] = 4
                }
                if ((array[y_value - 1][x_value - 1] == 3 || array[y_value - 1][x_value - 1] == 5 ) && array[y_value - 2][x_value - 2] == 1) {
                    array[y_value - 2][x_value - 2] = 4
                    blue_x = x_value - 1
                    blue_y = y_value - 1
                    capture = 1
                }
                if ((array[y_value - 1][x_value + 1] == 3 || array[y_value - 1][x_value + 1] == 5) && array[y_value - 2][x_value + 2] == 1) {
                    array[y_value - 2][x_value + 2] = 4
                    blue_x = x_value + 1
                    blue_y = y_value + 1
                    capture = 1
                }
                red_x = x_value
                red_y = y_value
            }
            else {
                if (array[y_value + 1][x_value + 1] == 1 && array[y_value + 1][x_value - 1] == 1 && jump_test() == 0) {
                    array[y_value + 1][x_value + 1] = 4
                    array[y_value + 1][x_value - 1] = 4
                } else if (array[y_value + 1][x_value + 1] == 1 && jump_test() == 0) {
                    array[y_value + 1][x_value + 1] = 4
                } else if (array[y_value + 1][x_value - 1] == 1 && jump_test() == 0) {
                    array[y_value + 1][x_value - 1] = 4
                }
                if ((array[y_value + 1][x_value - 1] == 3 || array[y_value + 1][x_value - 1] == 5) && array[y_value + 2][x_value - 2] == 1) {
                    array[y_value + 2][x_value - 2] = 4
                    blue_x = x_value - 1
                    blue_y = y_value + 1
                    capture = 1
                }
                if ((array[y_value + 1][x_value + 1] == 3 || array[y_value + 1][x_value + 1] == 5) && array[y_value + 2][x_value + 2] == 1) {
                    array[y_value + 2][x_value + 2] = 4
                    blue_x = x_value + 1
                    blue_y = y_value + 1
                    capture = 1
                }
                if (array[y_value - 1][x_value + 1] == 1 && array[y_value - 1][x_value - 1] == 1 && jump_test() == 0) {
                    array[y_value - 1][x_value + 1] = 4
                    array[y_value - 1][x_value - 1] = 4
                } else if (array[y_value - 1][x_value + 1] == 1 && jump_test() == 0) {
                    array[y_value - 1][x_value + 1] = 4
                } else if (array[y_value - 1][x_value - 1] == 1 && jump_test() == 0) {
                    array[y_value + 1][x_value - 1] = 4
                }
                if ((array[y_value - 1][x_value - 1] == 3 || array[y_value - 1][x_value - 1] == 5) && array[y_value - 2][x_value - 2] == 1) {
                    array[y_value - 2][x_value - 2] = 4
                    blue_x = x_value - 1
                    blue_y = y_value - 1
                    capture = 1
                }
                if ((array[y_value - 1][x_value + 1] == 3 || array[y_value - 1][x_value + 1] == 5) && array[y_value - 2][x_value + 2] == 1) {
                    array[y_value - 2][x_value + 2] = 4
                    blue_x = x_value + 1
                    blue_y = y_value - 1
                    capture = 1
                }
                red_x = x_value
                red_y = y_value
                invalidate()
            }
        }
        if(array[y_value][x_value] == 5 && current == 3){
            captured = 0
            Log.d("Checkers Red","Initiated")
            for(i in 0..8){
                for(j in 0..8){
                    if(array[j][i] == 4){
                        array[j][i] = 1
                    }
                }
            }
            capture = 0
            if(x_value == 0) {
                if (array[y_value + 1][x_value + 1] == 1 && jump_test() == 0) {
                    array[y_value + 1][x_value + 1] = 4
                }
                if (array[y_value - 1][x_value + 1] == 1 && jump_test() == 0) {
                    array[y_value - 1][x_value + 1] = 4
                }
                if ((array[y_value + 1][x_value + 1] == 2 || array[y_value + 1][x_value + 1] == 6) && array[y_value + 2][x_value + 2] == 1) {
                    array[y_value + 2][x_value + 2] = 4
                    red_x = x_value + 1
                    red_y = y_value + 1
                    capture = 1
                }
                if ((array[y_value - 1][x_value + 1] == 2 || array[y_value - 1][x_value + 1] == 6) && array[y_value - 2][x_value + 2] == 1) {
                    array[y_value - 2][x_value + 2] = 4
                    red_x = x_value + 1
                    red_y = y_value - 1
                    capture = 1
                }
                blue_x = x_value
                blue_y = y_value
                invalidate()
            }
            else if(x_value == 1 && y_value != 0 && y_value != 1) {
                if (array[y_value + 1][x_value + 1] == 1 && jump_test() == 0) {
                    array[y_value + 1][x_value + 1] = 4
                }
                if (array[y_value - 1][x_value + 1] == 1 && jump_test() == 0) {
                    array[y_value - 1][x_value + 1] = 4
                }
                if (array[y_value + 1][x_value - 1] == 1 && jump_test() == 0) {
                    array[y_value + 1][x_value - 1] = 4
                }
                if (array[y_value - 1][x_value - 1] == 1 && jump_test() == 0) {
                    array[y_value - 1][x_value - 1] = 4
                }
                if ((array[y_value + 1][x_value + 1] == 2 || array[y_value + 1][x_value + 1] == 6) && array[y_value + 2][x_value + 2] == 1) {
                    array[y_value + 2][x_value + 2] = 4
                    red_x = x_value + 1
                    red_y = y_value + 1
                    capture = 1
                }
                if ((array[y_value - 1][x_value + 1] == 2 || array[y_value - 1][x_value + 1] == 6) && array[y_value - 2][x_value + 2] == 1) {
                    array[y_value - 2][x_value + 2] = 4
                    red_x = x_value + 1
                    red_y = y_value - 1
                    capture = 1
                }
                blue_x = x_value
                blue_y = y_value
                invalidate()
            }
            else if(y_value == 0){
                if (array[y_value + 1][x_value + 1] == 1 && array[y_value + 1][x_value - 1] == 1 && jump_test() == 0) {
                    array[y_value + 1][x_value + 1] = 4
                    array[y_value + 1][x_value - 1] = 4
                } else if (array[y_value + 1][x_value + 1] == 1 && jump_test() == 0) {
                    array[y_value + 1][x_value + 1] = 4
                } else if (array[y_value + 1][x_value - 1] == 1 && jump_test() == 0) {
                    array[y_value + 1][x_value - 1] = 4
                }
                if ((array[y_value + 1][x_value - 1] == 2 || (array[y_value+1][x_value-1] == 6)) && array[y_value + 2][x_value - 2] == 1) {
                    array[y_value + 2][x_value - 2] = 4
                    red_x = x_value - 1
                    red_y = y_value + 1
                    capture = 1
                }
                if ((array[y_value + 1][x_value + 1] == 2 && array[y_value+1][x_value+1] == 6) && array[y_value + 2][x_value + 2] == 1) {
                    array[y_value + 2][x_value + 2] = 4
                    red_x = x_value + 1
                    red_y = y_value + 1
                    capture = 1
                }
                blue_x = x_value
                blue_y = y_value
            }
            else if(y_value == 1){
                if(array[y_value+1][x_value+1] == 1 && jump_test() == 0){
                    array[y_value+1][x_value+1] = 4
                }
                if (array[y_value + 1][x_value - 1] == 1 &&  jump_test() == 0) {
                    array[y_value + 1][x_value - 1] = 4
                }
                if (array[y_value - 1][x_value + 1] == 1 && array[y_value - 1][x_value - 1] == 1 && jump_test() == 0) {
                    array[y_value - 1][x_value + 1] = 4
                    array[y_value - 1][x_value - 1] = 4
                }
                else if (array[y_value - 1][x_value + 1] == 1 && jump_test() == 0) {
                    array[y_value - 1][x_value + 1] = 4
                }
                else if (array[y_value - 1][x_value - 1] == 1 && jump_test() == 0) {
                    array[y_value + 1][x_value - 1] = 4
                }
                if (array[y_value + 1][x_value - 1] == 2 && array[y_value + 2][x_value - 2] == 1) {
                    array[y_value + 2][x_value - 2] = 4
                    red_x = x_value - 1
                    red_y = y_value + 1
                    capture = 1
                }
                if (array[y_value + 1][x_value + 1] == 2 && array[y_value + 2][x_value + 2] == 1) {
                    array[y_value + 2][x_value + 2] = 4
                    red_x = x_value + 1
                    red_y = y_value + 1
                    capture = 1
                }
                blue_x = x_value
                blue_y = y_value
            }
            else {
                if (array[y_value + 1][x_value + 1] == 1 && array[y_value + 1][x_value - 1] == 1 && jump_test() == 0) {
                    array[y_value + 1][x_value + 1] = 4
                    array[y_value + 1][x_value - 1] = 4
                } else if (array[y_value + 1][x_value + 1] == 1 && jump_test() == 0) {
                    array[y_value + 1][x_value + 1] = 4
                } else if (array[y_value + 1][x_value - 1] == 1 && jump_test() == 0) {
                    array[y_value + 1][x_value - 1] = 4
                }
                if ((array[y_value + 1][x_value - 1] == 2 || array[y_value + 1][x_value - 1] == 6)&& array[y_value + 2][x_value - 2] == 1) {
                    array[y_value + 2][x_value - 2] = 4
                    red_x = x_value - 1
                    red_y = y_value + 1
                    capture = 1
                }
                if (array[y_value + 1][x_value + 1] == 2 && array[y_value + 2][x_value + 2] == 1) {
                    array[y_value + 2][x_value + 2] = 4
                    red_x = x_value + 1
                    red_y = y_value + 1
                    capture = 1
                }
                if (array[y_value - 1][x_value + 1] == 1 && array[y_value - 1][x_value - 1] == 1 && jump_test() == 0) {
                    array[y_value - 1][x_value + 1] = 4
                    array[y_value - 1][x_value - 1] = 4
                } else if (array[y_value - 1][x_value + 1] == 1 && jump_test() == 0) {
                    array[y_value - 1][x_value + 1] = 4
                } else if (array[y_value - 1][x_value - 1] == 1 && jump_test() == 0) {
                    array[y_value + 1][x_value - 1] = 4
                }
                if (array[y_value - 1][x_value - 1] == 2 && array[y_value - 2][x_value - 2] == 1) {
                    array[y_value - 2][x_value - 2] = 4
                    red_x = x_value - 1
                    red_y = y_value - 1
                    capture = 1
                }
                if (array[y_value - 1][x_value + 1] == 2 && array[y_value - 2][x_value + 2] == 1) {
                    array[y_value - 2][x_value + 2] = 4
                    red_x = x_value + 1
                    red_y = y_value - 1
                    capture = 1
                }
                blue_x = x_value
                blue_y = y_value
                invalidate()
            }
        }
        }

        /*if (array[x_value+ i][y_value + j] == waiting) {
            Log.d("X,y",x_value.toString() + " " + y_value.toString())
            if (array[x_value + i + i][y_value + j + j] == current) {
                if(replace == 1) {
                    array[x_value + i][y_value + j] = current
                    array[x_value][y_value] = current

                    val temp = current
                    current = waiting
                    waiting = temp
                }

            }
        }*/

    private fun Score(a : Int) : Int{
        var b = 0
        for(i in 0..8){
            for(j in 0..8){
                if(array[j][i] == a){
                    b = b + 1
                }
            }
        }
        if(current == 2){
            for(i in 0..8){
                for(j in 0..8){
                    if(array[j][i] == 6){
                        b = b + 1
                    }
                }
            }
        }
        if(current == 3){
            for(i in 0..8){
                for(j in 0..8){
                    if(array[j][i] == 5){
                        b = b + 1
                    }
                }
            }
        }
        return b
    }
    private fun jump_test(): Int{
        var b =0
        for(i in 0..7){
            for(j in 0..7){
                if(current == 2){
                    if(j == 0 || j == 1 && i != 6){
                        if (array[i][j] == 2 && (array[i + 1][j + 1] == 3 || array[i + 1][j + 1] == 5) && array[i + 2][j + 2] == 1){
                            if(i == red_y && j == red_x){
                                Log.d("Error","1")
                                b = 2
                                return b
                            }
                            b = 1

                        }
                        if (array[i][j] == 6 && (array[i + 1][j + 1] == 3 || array[i + 1][j + 1] == 5) && array[i + 2][j + 2] == 1){
                            if(i == red_y && j == red_x){
                                b = 2
                                return b
                                Log.d("Error","2")
                            }
                            b = 1
                            return b
                        }
                    }
                    else if(i == 6 || i == 7 && (j != 1 || j != 0)){

                        if (array[i][j] == 6 && (array[i - 1][j - 1] == 3 || array[i - 1][j - 1] == 5) && array[i + 2][j - 2] == 1){
                            if(i == red_y && j == red_x){
                                //check1
                                Log.d("Error","3")
                                b = 0
                                return b
                            }
                            b = 0


                        }
                        if (array[i][j] == 6 && (array[i - 1][j + 1]  == 3|| array[i-1][j+1] == 5) && array[i + 2][j + 2] == 1){
                            b = 0
                            Log.d("Error","4")
                            return b
                        }
                        b = 0

                    }
                    else if (j == 6){
                        if (array[i][j] == 2 && (array[i + 1][j - 1] == 3 || array[i + 1][j - 1] == 5) && array[i + 2][j - 2] == 1){
                            if(i == red_y && j == red_x){
                                b = 2
                                Log.d("Error","5")
                                return b
                            }
                            b = 1
                            return b
                        }
                        if (array[i][j] == 6 && (array[i + 1][j - 1] == 3 || array[i + 1][j - 1] == 5) && array[i + 2][j - 2] == 1){
                            if(i == red_y && j == red_x){
                                Log.d("Error","6")
                                b = 2
                                return b
                            }
                            b = 1
                            return b
                        }
                    }
                    else if (j != 0 && j != 1 && i != 6 && i != 7){
                        if (array[i][j] == 2 && (array[i + 1][j - 1] == 3 || array[i + 1][j - 1] == 5) && array[i + 2][j - 2] == 1){
                            if(i == red_y && j == red_x){
                                Log.d("Error","7")
                                b = 2
                                return b
                            }
                            b = 1
                            return b
                        }
                        if (array[i][j] == 2 && (array[i + 1][j + 1] == 3 || array[i + 1][j + 1] == 5) && array[i + 2][j + 2] == 1){
                            if(i == red_y && j == red_x){
                                Log.d("Error","10")
                                b = 2
                                return b
                            }
                            b = 1
                            return b
                        }
                        if (array[i][j] == 6 && (array[i + 1][j - 1] == 3 || array[i + 1][j - 1] == 5) && array[i + 2][j - 2] == 1){
                            if(i == red_y && j == red_x){
                                Log.d("Error","11")
                                b = 2
                                return b
                            }
                            b = 1
                            return b
                        }
                        if (array[i][j] == 6 && (array[i + 1][j + 1] == 3 || array[i + 1][j + 1] == 5) && array[i + 2][j + 2] == 1){
                            if(i == red_y && j == red_x){
                                Log.d("Error","12")
                                b = 2
                                return b
                            }
                            b = 1
                            return b
                        }
                        if (array[i][j] == 6 && (array[i - 1][j - 1]  == 3|| array[i - 1][j - 1] == 5) && array[i + 2][j - 2] == 1){
                            if(i == red_y && j == red_x){
                                Log.d("Error","13")
                                b = 2
                                return b
                            }
                            b = 1
                            return b
                        }
                        if (array[i][j] == 6 && (array[i - 1][j + 1] == 3 || array[i - 1][j + 1] == 5) && array[i + 2][j + 2] == 1){
                            if(i == red_y && j == red_x){
                                Log.d("Error","14")
                                b = 2
                                return b
                            }
                            b = 1
                            return b
                        }

                    }

                    else if (i == 6){b = 0}

                }
                if(current == 3){
                    if(j == 0|| j == 1 && i != 0 && i != 1){
                        if (array[i][j] == 3 && (array[i - 1][j + 1] == 2||array[i - 1][j + 1] == 6) && array[i - 2][j + 2] == 1){
                            if(i == blue_y && j == blue_x){
                                b = 2
                                return b
                            }
                            b = 1
                            return b
                        }
                        if (array[i][j] == 5 && (array[i + 1][j + 1] == 2||array[i + 1][j + 1] == 6) && array[i - 2][j + 2] == 1){
                            if(i == blue_y && j == blue_x){
                                b = 2
                                return b
                            }
                            b = 1
                            return b
                        }
                    }
                    if(i == 0 && i == 1 && j != 0 && j != 1){
                        if (array[i][j] == 5 && (array[i + 1][j - 1] == 2 || array[i+1][j-1] == 6) && array[i - 2][j - 2] == 1){
                            if(i == blue_y && j == blue_x){
                                b = 2
                                return b
                            }
                            b = 1
                            return b
                        }
                        if (array[i][j] == 5 && array[i + 1][j + 1] == 2 && array[i - 2][j + 2] == 1){
                            if(i == blue_y && j == blue_x){
                                b = 2
                                return b
                            }
                            b = 1
                            return b
                        }
                    }

                    else if(i != 0 && i != 1 && j != 0 && j != 1){
                        if (array[i][j] == 3 && (array[i - 1][j - 1] == 2) && array[i - 2][j - 2] == 1){
                            if(i == blue_y && j == blue_x){
                                b = 2
                                return b
                            }
                            b = 1
                            return b
                            }
                            if (array[i][j] == 3 && array[i - 1][j + 1] == 2 && array[i - 2][j + 2] == 1){
                                if(i == blue_y && j == blue_x){
                                    b = 2
                                    return b
                                }
                                b = 1
                                return b
                            }
                        if (array[i][j] == 5 && (array[i - 1][j - 1] == 2) && array[i - 2][j - 2] == 1){
                            if(i == blue_y && j == blue_x){
                                b = 2
                                return b
                            }
                            b = 1
                            return b
                        }
                        if (array[i][j] == 5 && array[i - 1][j + 1] == 2 && array[i - 2][j + 2] == 1){
                            if(i == blue_y && j == blue_x){
                                b = 2
                                return b
                            }
                            b = 1
                            return b
                        }
                        if (array[i][j] == 5 && (array[i + 1][j - 1] == 2) && array[i - 2][j - 2] == 1){

                            b = 2
                            return b
                        }
                        if (array[i][j] == 5 && array[i + 1][j + 1] == 2 && array[i - 2][j + 2] == 1){
                            if(i == blue_y && j == blue_x){
                                b = 2
                                return b
                            }
                            b = 1
                            return b
                        }
                    }
                }
                }
            }

        return b
    }
}